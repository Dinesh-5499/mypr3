from django.http import HttpResponseRedirect
from django.shortcuts import redirect, render
from .forms import StudentRegistration
from .models import User

# Create your views here.
def add_show(request):
    if request.method == 'POST':
        fm = StudentRegistration(request.POST)
        if fm.is_valid():
            fm.save()
            return redirect('addandshow')
    else:
        fm = StudentRegistration()
    stu = User.objects.all()
    return render(request,'crudapp/addandshow.html',{'form':fm,'stu':stu})
def delete(request,id):
    if request.method == "POST":
        pi = User.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')

def update(request,id):
    if request.method == "POST":
        pi = User.objects.get(pk=id)
        sm = StudentRegistration(request.POST,instance=pi)
        if sm.is_valid():
            sm.save()
    else:
        pi = User.objects.get(pk=id)
        sm = StudentRegistration(instance=pi)
    return render(request,'crudapp/update.html',{"form":sm})